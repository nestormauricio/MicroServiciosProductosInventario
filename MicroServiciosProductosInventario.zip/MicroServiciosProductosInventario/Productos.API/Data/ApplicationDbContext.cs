using Microsoft.EntityFrameworkCore;
using Productos.API.Models;

namespace Productos.API.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        public DbSet<Producto> Productos { get; set; }
    }
}