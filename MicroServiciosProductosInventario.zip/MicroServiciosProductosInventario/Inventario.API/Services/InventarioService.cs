using System.Collections.Generic;
using System.Linq;

public class InventarioService
{
    private readonly InventarioDbContext _context;

    public InventarioService(InventarioDbContext context)
    {
        _context = context;
    }

    public IEnumerable<InventarioItem> GetAll() => _context.Inventarios.ToList();

    public bool VerificarStock(int productoId, int cantidad)
    {
        var inventario = _context.Inventarios.FirstOrDefault(i => i.ProductoId == productoId);
        return inventario != null && inventario.Cantidad >= cantidad;
    }

    public bool ActualizarStock(int productoId, int cantidad)
    {
        var inventario = _context.Inventarios.FirstOrDefault(i => i.ProductoId == productoId);
        if (inventario == null || inventario.Cantidad < cantidad)
            return false;

        inventario.Cantidad -= cantidad;
        _context.SaveChanges();
        return true;
    }
}