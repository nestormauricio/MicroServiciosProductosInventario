using System.Linq;

public class InventarioSeeder
{
    private readonly InventarioDbContext _context;

    public InventarioSeeder(InventarioDbContext context)
    {
        _context = context;
    }

    public void Seed()
    {
        _context.Database.EnsureCreated();

        if (!_context.Inventarios.Any())
        {
            _context.Inventarios.AddRange(
                new InventarioItem { ProductoId = 1, Cantidad = 100 },
                new InventarioItem { ProductoId = 2, Cantidad = 50 },
                new InventarioItem { ProductoId = 3, Cantidad = 75 },
                new InventarioItem { ProductoId = 4, Cantidad = 20 },
                new InventarioItem { ProductoId = 5, Cantidad = 60 }
            );
            _context.SaveChanges();
        }
    }
}