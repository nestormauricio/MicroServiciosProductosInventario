using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

public class ApiKeyMiddleware
{
    private readonly RequestDelegate _next;
    private const string API_KEY = "X-API-KEY";
    private const string EXPECTED_KEY = "super-secret-key";

    public ApiKeyMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task Invoke(HttpContext context)
    {
        if (!context.Request.Headers.TryGetValue(API_KEY, out var extractedApiKey) || extractedApiKey != EXPECTED_KEY)
        {
            context.Response.StatusCode = 401;
            await context.Response.WriteAsync("API Key inválida o faltante.");
            return;
        }

        await _next(context);
    }
}