using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class InventarioController : ControllerBase
{
    private readonly InventarioService _service;

    public InventarioController(InventarioService service)
    {
        _service = service;
    }

    [HttpGet]
    public IActionResult Get() => Ok(_service.GetAll());

    [HttpPost("verificar")]
    public IActionResult Verificar([FromBody] InventarioItem input)
    {
        bool ok = _service.VerificarStock(input.ProductoId, input.Cantidad);
        return Ok(new { disponible = ok });
    }

    [HttpPost("actualizar")]
    public IActionResult Actualizar([FromBody] InventarioItem input)
    {
        bool ok = _service.ActualizarStock(input.ProductoId, input.Cantidad);
        return Ok(new { actualizado = ok });
    }
}