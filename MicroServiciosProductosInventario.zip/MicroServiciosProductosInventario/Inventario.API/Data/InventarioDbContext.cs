using Microsoft.EntityFrameworkCore;

public class InventarioDbContext : DbContext
{
    public InventarioDbContext(DbContextOptions<InventarioDbContext> options) : base(options) { }

    public DbSet<InventarioItem> Inventarios => Set<InventarioItem>();

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            var conn = "Server=sqlserver_productos;Database=InventarioDb;User Id=sa;Password=sa;";
            optionsBuilder.UseSqlServer(conn);
        }
    }
}