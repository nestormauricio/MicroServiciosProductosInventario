using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddScoped<InventarioService>();
builder.Services.AddDbContext<InventarioDbContext>();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.UseMiddleware<ApiKeyMiddleware>();

app.MapControllers();

// Cargar datos al iniciar
using (var scope = app.Services.CreateScope())
{
    var seeder = new InventarioSeeder(scope.ServiceProvider.GetRequiredService<InventarioDbContext>());
    seeder.Seed();
}

app.Run();