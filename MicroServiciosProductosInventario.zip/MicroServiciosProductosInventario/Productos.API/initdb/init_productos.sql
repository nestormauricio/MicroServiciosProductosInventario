IF DB_ID('ProductosDB') IS NULL
    CREATE DATABASE ProductosDB;
GO

USE ProductosDB;
GO

IF OBJECT_ID('dbo.Productos', 'U') IS NOT NULL
    DROP TABLE dbo.Productos;
GO

CREATE TABLE Productos (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(100) NOT NULL,
    Precio DECIMAL(18, 2) NOT NULL,
    Descripcion NVARCHAR(255)
);
GO

INSERT INTO Productos (Nombre, Precio, Descripcion)
VALUES 
('Laptop Dell Inspiron', 2800.00, 'Laptop de 14 pulgadas con 16GB RAM'),
('Mouse Logitech', 120.50, 'Mouse inalámbrico ergonómico'),
('Teclado Mecánico', 230.00, 'Switches rojos retroiluminado'),
('Monitor LG 24\"', 720.00, 'Full HD HDMI'),
('Disco SSD 1TB', 450.00, 'M.2 NVMe rápido');
GO