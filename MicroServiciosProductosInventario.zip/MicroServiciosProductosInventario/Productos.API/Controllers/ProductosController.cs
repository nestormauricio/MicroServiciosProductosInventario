using Microsoft.AspNetCore.Mvc;
using Productos.API.Models;
using Productos.API.Services;
using System.Threading.Tasks;

namespace Productos.API.Controllers
{
    [ApiController]
    [Route("api/productos")]
    [Produces("application/vnd.api+json")]
    public class ProductosController : ControllerBase
    {
        private readonly ProductoService _service;

        public ProductosController(ProductoService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var productos = await _service.ListarAsync();
            return Ok(new { data = productos });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var producto = await _service.ObtenerPorIdAsync(id);
            if (producto == null)
                return NotFound(new { errors = new[] { "Producto no encontrado" } });

            return Ok(new { data = producto });
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Producto producto)
        {
            var creado = await _service.CrearAsync(producto);
            return CreatedAtAction(nameof(GetById), new { id = creado.Id }, new { data = creado });
        }
    }
}